package lt.bit.bandomasis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BandomasisApplicationTests {

	@Test
	void contextLoads() {
	}

}
